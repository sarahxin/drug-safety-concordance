import pandas as pd
import numpy as np
import concurrent.futures
from tqdm import tqdm
from scipy.stats import fisher_exact

# load the main concordance-ready file (prepared from harmonizer)
data_file_concordance = "./offx_PP_ready4concordance.csv"

try:
    df_all = pd.read_csv(data_file_concordance)
except Exception as e:
    print("Could not load concordance file:", data_file_concordance)
    raise e

# run different drug types
drug_types_to_run = ["biotech", "small molecule", "all"]

for drug_type_to_use in drug_types_to_run:
    print("\n= Running SOC concordance for drug type:", drug_type_to_use, "=")
    
    if drug_type_to_use == "all":
        df = df_all.copy()
    else:
        df = df_all[df_all['drug_type'] == drug_type_to_use].copy()
    

    human_mask = df['human_animal'] == 'human'
    preclinical_mask = df['human_animal'] == 'animal'

    human_df = df[human_mask].copy()
    preclinical_df = df[preclinical_mask].copy()

    # threshold for how many times a SOC must appear to be included (can adjust if needed)
    clin_threshold = 0
    preclin_threshold = 0

    # get the SOCs 
    human_soc_freq = human_df['soc_name'].value_counts()
    common_human_soc = human_soc_freq[human_soc_freq > clin_threshold].index.tolist()
    human_df_filtered = human_df[human_df['soc_name'].isin(common_human_soc)].copy()

    preclinical_soc_freq = preclinical_df['soc_name'].value_counts()
    common_preclinical_soc = preclinical_soc_freq[preclinical_soc_freq > preclin_threshold].index.tolist()
    preclinical_df_filtered = preclinical_df[preclinical_df['soc_name'].isin(common_preclinical_soc)].copy()

    # group the filtered data by SOC (for humans) and by SOCspecies (for preclinical)
    human_df_grouped = human_df_filtered.groupby('soc_name')
    preclinical_df_grouped = preclinical_df_filtered.groupby(['soc_name', 'species_group'])

    # compute confusion matrix
    def compute_stats_with_drugs(human_drugs, preclinical_drugs, species_drugs):
        tp_drugs = human_drugs.intersection(preclinical_drugs)
        fn_drugs = human_drugs.difference(preclinical_drugs)
        fp_drugs = preclinical_drugs.difference(human_drugs)
        tn_drugs = species_drugs.difference(human_drugs.union(preclinical_drugs))
        return tn_drugs, fp_drugs, fn_drugs, tp_drugs

    # process each SOC/species combo
    def process_soc_species(soc, species, human_df_grouped, preclinical_df_grouped, preclinical_df_filtered):
        results = []
        try:
            human_group = human_df_grouped.get_group(soc)
        except KeyError:
            return results
        human_drugs = set(human_group['drug'].astype(str))

        species_mask = preclinical_df_filtered['species_group'] == species
        species_drugs = set(preclinical_df_filtered[species_mask]['drug'].astype(str))
        human_drugs_tested_in_species = species_drugs.intersection(human_drugs)

        if len(human_drugs_tested_in_species) == 0:
            return results

        try:
            preclinical_group = preclinical_df_grouped.get_group((soc, species))
        except KeyError:
            return results

        preclinical_drugs = set(preclinical_group['drug'].astype(str))

        tn_drugs, fp_drugs, fn_drugs, tp_drugs = compute_stats_with_drugs(
            human_drugs_tested_in_species, preclinical_drugs, species_drugs
        )

        contingency_table = [[len(tp_drugs), len(fp_drugs)], [len(fn_drugs), len(tn_drugs)]]
        try:
            _, p_value = fisher_exact(contingency_table)
        except Exception:
            p_value = np.nan

        results.append({
            'SOC': soc,
            'Species': species,
            'TP': len(tp_drugs),
            'TP_Drugs': ', '.join(tp_drugs),
            'FN': len(fn_drugs),
            'FN_Drugs': ', '.join(fn_drugs),
            'FP': len(fp_drugs),
            'FP_Drugs': ', '.join(fp_drugs),
            'TN': len(tn_drugs),
            'TN_Drugs': ', '.join(tn_drugs),
            'Fisher_p_value': p_value
        })
        return results

    # process combined
    def process_soc_combined(soc, human_df_grouped, preclinical_df_filtered):
        results = []
        try:
            human_group = human_df_grouped.get_group(soc)
        except KeyError:
            return results
        human_drugs = set(human_group['drug'].astype(str))
        combined_species_drugs = set(preclinical_df_filtered['drug'].astype(str))
        human_drugs_tested_in_any_species = combined_species_drugs.intersection(human_drugs)

        if len(human_drugs_tested_in_any_species) == 0:
            return results

        preclinical_group = preclinical_df_filtered[preclinical_df_filtered['SOC'] == soc]
        preclinical_drugs = set(preclinical_group['drug'].astype(str))

        tn_drugs, fp_drugs, fn_drugs, tp_drugs = compute_stats_with_drugs(
            human_drugs_tested_in_any_species, preclinical_drugs, combined_species_drugs
        )

        contingency_table = [[len(tp_drugs), len(fp_drugs)], [len(fn_drugs), len(tn_drugs)]]
        try:
            _, p_value = fisher_exact(contingency_table)
        except Exception:
            p_value = np.nan

        results.append({
            'SOC': soc,
            'Species': 'Combined',
            'TP': len(tp_drugs),
            'TP_Drugs': ', '.join(tp_drugs),
            'FN': len(fn_drugs),
            'FN_Drugs': ', '.join(fn_drugs),
            'FP': len(fp_drugs),
            'FP_Drugs': ', '.join(fp_drugs),
            'TN': len(tn_drugs),
            'TN_Drugs': ', '.join(tn_drugs),
            'Fisher_p_value': p_value
        })
        return results

    # build up list of all SOC/species pairs to process
    soc_species_pairs = []
    for soc in human_df_filtered['soc_name'].unique():
        for species in preclinical_df_filtered['species_group'].unique():
            soc_species_pairs.append((soc, species))
        soc_species_pairs.append((soc, 'Combined'))

    # collect results
    results = []

    with concurrent.futures.ProcessPoolExecutor() as executor:
        futures = []
        for soc, species in tqdm(soc_species_pairs, desc=f"Submitting SOC/species tasks for {drug_type_to_use}"):
            if species == 'Combined':
                futures.append(executor.submit(process_soc_combined, soc, human_df_grouped, preclinical_df_filtered))
            else:
                futures.append(executor.submit(process_soc_species, soc, species, human_df_grouped, preclinical_df_grouped, preclinical_df_filtered))
        for future in tqdm(concurrent.futures.as_completed(futures), total=len(futures), desc=f"Collecting results for {drug_type_to_use}"):
            try:
                res = future.result()
                if res:
                    results.extend(res)
            except Exception:
                continue


    results_df = pd.DataFrame(results)

    # save for downstream analysis
    output_concordance_file = f"soc_concordance_results_{drug_type_to_use.replace(' ', '_')}.csv"
    results_df.to_csv(output_concordance_file, index=False)
    print(f"Saved SOC-level concordance results for '{drug_type_to_use}' to {output_concordance_file}")

print("\nAll SOC-level concordance analyses complete.")
