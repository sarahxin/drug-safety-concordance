import pandas as pd
import numpy as np
from tqdm import tqdm
from scipy.stats import fisher_exact
from statsmodels.stats.multitest import multipletests

# load data from previous 
df_all = pd.read_csv("./offx_PP_ready4concordance.csv")

# stratified analysis on type
drug_type = "small molecule"  
if drug_type == "all":
    df = df_all.copy()
else:
    df = df_all[df_all.drug_type == drug_type].copy()

human_df = df[df['human_animal'] == 'human']
preclinical_df = df[df['human_animal'] == 'animal']

# threshold
clin_threshold = 0
preclin_threshold = 0

human_ae_freq = human_df['adverse_event'].value_counts()
common_human_ae = human_ae_freq[human_ae_freq > clin_threshold].index
human_df_filtered = human_df[human_df['adverse_event'].isin(common_human_ae)]

preclinical_ae_freq = preclinical_df['adverse_event'].value_counts()
common_preclinical_ae = preclinical_ae_freq[preclinical_ae_freq > preclin_threshold].index
preclinical_df_filtered = preclinical_df[preclinical_df['adverse_event'].isin(common_preclinical_ae)]

human_df_grouped = human_df_filtered.groupby(['SOC', 'adverse_event'])
preclinical_df_grouped = preclinical_df_filtered.groupby(['SOC', 'species_group', 'adverse_event'])

def compute_stats_with_drugs(human_drugs, preclinical_drugs, species_drugs):
    tp_drugs = human_drugs & preclinical_drugs
    fn_drugs = human_drugs - preclinical_drugs
    fp_drugs = preclinical_drugs - human_drugs
    tn_drugs = species_drugs - (human_drugs | preclinical_drugs)
    return tn_drugs, fp_drugs, fn_drugs, tp_drugs

def process_soc_ae_species(soc, human_ae, species, human_df_grouped, preclinical_df_grouped, preclinical_df_filtered):
    results = []
    # get drugs forSOC/AE
    try:
        human_group = human_df_grouped.get_group((soc, human_ae))
    except KeyError:
        return results
    human_drugs = set(human_group['drug'].astype(str))
    # all drugs tested in species
    species_drugs = set(preclinical_df_filtered[preclinical_df_filtered['species_group'] == species]['drug'].astype(str))
    human_drugs_tested_in_species = species_drugs & human_drugs
    if not human_drugs_tested_in_species:
        return results
    # all preclinical AEs in this SOC/species
    preclinical_ae_list = preclinical_df_filtered[(preclinical_df_filtered['SOC'] == soc) & (preclinical_df_filtered['species_group'] == species)]['adverse_event'].unique()
    for preclinical_ae in preclinical_ae_list:
        try:
            preclinical_group = preclinical_df_grouped.get_group((soc, species, preclinical_ae))
        except KeyError:
            continue
        preclinical_drugs = set(preclinical_group['drug'].astype(str))
        tn_drugs, fp_drugs, fn_drugs, tp_drugs = compute_stats_with_drugs(human_drugs_tested_in_species, preclinical_drugs, species_drugs)
        contingency_table = [[len(tp_drugs), len(fp_drugs)], [len(fn_drugs), len(tn_drugs)]]
        _, p_value = fisher_exact(contingency_table)
        results.append({
            'SOC': soc,
            'Human_AE': human_ae,
            'Preclinical_AE': preclinical_ae,
            'Species': species,
            'TP': len(tp_drugs),
            'TP_Drugs': ', '.join(tp_drugs),
            'FN': len(fn_drugs),
            'FN_Drugs': ', '.join(fn_drugs),
            'FP': len(fp_drugs),
            'FP_Drugs': ', '.join(fp_drugs),
            'TN': len(tn_drugs),
            'Fisher_p_value': p_value
        })
    return results

def process_soc_ae_combined(soc, human_ae, human_df_grouped, preclinical_df_filtered):
    results = []
    try:
        human_group = human_df_grouped.get_group((soc, human_ae))
    except KeyError:
        return results
    human_drugs = set(human_group['drug'].astype(str))
    combined_species_drugs = set(preclinical_df_filtered['drug'].astype(str))
    human_drugs_tested_in_any_species = combined_species_drugs & human_drugs
    if not human_drugs_tested_in_any_species:
        return results
    preclinical_ae_list = preclinical_df_filtered[preclinical_df_filtered['SOC'] == soc]['adverse_event'].unique()
    for preclinical_ae in preclinical_ae_list:
        preclinical_group = preclinical_df_filtered[(preclinical_df_filtered['SOC'] == soc) & (preclinical_df_filtered['adverse_event'] == preclinical_ae)]
        preclinical_drugs = set(preclinical_group['drug'].astype(str))
        tn_drugs, fp_drugs, fn_drugs, tp_drugs = compute_stats_with_drugs(human_drugs_tested_in_any_species, preclinical_drugs, combined_species_drugs)
        contingency_table = [[len(tp_drugs), len(fp_drugs)], [len(fn_drugs), len(tn_drugs)]]
        _, p_value = fisher_exact(contingency_table)
        results.append({
            'SOC': soc,
            'Human_AE': human_ae,
            'Preclinical_AE': preclinical_ae,
            'Species': 'Combined',
            'TP': len(tp_drugs),
            'TP_Drugs': ', '.join(tp_drugs),
            'FN': len(fn_drugs),
            'FN_Drugs': ', '.join(fn_drugs),
            'FP': len(fp_drugs),
            'FP_Drugs': ', '.join(fp_drugs),
            'TN': len(tn_drugs),
            'Fisher_p_value': p_value
        })
    return results

results = []
for soc in tqdm(human_df_filtered['SOC'].unique(), desc="Processing SOC Terms"):
    human_ae_list = human_df_filtered[human_df_filtered['SOC'] == soc]['adverse_event'].unique()
    for human_ae in human_ae_list:
        for species in preclinical_df_filtered['species_group'].unique():
            results.extend(process_soc_ae_species(soc, human_ae, species, human_df_grouped, preclinical_df_grouped, preclinical_df_filtered))
        results.extend(process_soc_ae_combined(soc, human_ae, human_df_grouped, preclinical_df_filtered))

results_df = pd.DataFrame(results)
results_df['PPV'] = results_df['TP'] / (results_df['TP'] + results_df['FP'])
results_df['NPV'] = results_df['TN'] / (results_df['TN'] + results_df['FN'])
results_df['Positive_Likelihood_Ratio'] = (results_df['TP'] / (results_df['TP'] + results_df['FN'])) / \
                                           (results_df['FP'] / (results_df['FP'] + results_df['TN']))
results_df['Negative_Likelihood_Ratio'] = (results_df['FN'] / (results_df['TP'] + results_df['FN'])) / \
                                           (results_df['TN'] / (results_df['FP'] + results_df['TN']))
results_df["1/Negative_Likelihood_Ratio"] = results_df["Negative_Likelihood_Ratio"].apply(lambda x: 1/x if x != 0 else np.inf)

def p_value_correction(group, method='bonferroni'):
    group['Adjusted_p_value'] = multipletests(group['Fisher_p_value'], method=method, alpha=0.05)[1]
    return group
results_df = results_df.groupby(['SOC', 'Species']).apply(p_value_correction)
results_df.reset_index(drop=True, inplace=True)

# annotate
drug_targets = pd.read_csv("./drugbank_offx_targets.csv") # primaryand secondary targets retrieved from off-x and drugbank with license
df_target_4map_dict = dict(zip(drug_targets.drug_name,drug_targets.targets))
def map_drug_targets(drug_list, drug_target_dict):
    if pd.isna(drug_list):
        return []
    drug_list = [drug.strip() for drug in drug_list.split(',')] if isinstance(drug_list, str) else []
    target_list = []
    for drug in drug_list:
        targets = drug_target_dict.get(drug, [])
        if isinstance(targets, str) and targets != 'nan':
            try:
                targets = eval(targets)
            except:
                targets = []
        target_list.extend(targets)
    return list(set(target_list))
from tqdm import tqdm
tqdm.pandas()
results_df['TP_Targets'] = results_df['TP_Drugs'].progress_apply(lambda x: map_drug_targets(x, df_target_4map_dict))
results_df['FN_Targets'] = results_df['FN_Drugs'].progress_apply(lambda x: map_drug_targets(x, df_target_4map_dict))
results_df['FP_Targets'] = results_df['FP_Drugs'].progress_apply(lambda x: map_drug_targets(x, df_target_4map_dict))

results_df.to_csv(f"nonidentical_term_concordance_{drug_type.replace(' ', '_')}.csv", index=False)
