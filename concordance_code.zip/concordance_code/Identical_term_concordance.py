import pandas as pd
import numpy as np
from tqdm import tqdm
from scipy.stats import fisher_exact
from statsmodels.stats.multitest import multipletests

# load file for concordance
df_all = pd.read_csv("./offx_PP_ready4concordance.csv")

# stratified analysis on drug type
drug_types = ["small molecule", "biotech", "all"]
for drug_type in drug_types:
    print(f"\nProcessing drug type: {drug_type}")
    if drug_type == "all":
        df = df_all.copy()
    else:
        df = df_all[df_all.drug_type == drug_type].copy()

    human_df = df[df['human_animal'] == 'human'].copy()
    preclinical_df = df[df['human_animal'] == 'animal'].copy()

    clin_threshold = 0
    preclin_threshold = 0
    human_ae_freq = human_df['adverse_event'].value_counts()
    common_human_ae = human_ae_freq[human_ae_freq > clin_threshold].index
    human_df_filtered = human_df[human_df['adverse_event'].isin(common_human_ae)].copy()

    preclinical_ae_freq = preclinical_df['adverse_event'].value_counts()
    common_preclinical_ae = preclinical_ae_freq[preclinical_ae_freq > preclin_threshold].index
    preclinical_df_filtered = preclinical_df[preclinical_df['adverse_event'].isin(common_preclinical_ae)].copy()

    human_df_grouped = human_df_filtered.groupby(['SOC', 'adverse_event'])
    preclinical_df_grouped = preclinical_df_filtered.groupby(['SOC', 'species_group', 'adverse_event'])

    # helper for TP/FP/FN/TN 
    def compute_stats_with_drugs(human_drugs, preclinical_drugs, species_drugs):
        tp_drugs = human_drugs.intersection(preclinical_drugs)
        fn_drugs = human_drugs.difference(preclinical_drugs)
        fp_drugs = preclinical_drugs.difference(human_drugs)
        tn_drugs = species_drugs.difference(human_drugs.union(preclinical_drugs))
        return tn_drugs, fp_drugs, fn_drugs, tp_drugs

    # process ae/species
    def process_soc_ae_species(soc, ae, species, human_df_grouped, preclinical_df_grouped):
        results = []
        try:
            human_group = human_df_grouped.get_group((soc, ae))
        except KeyError:
            return results
        human_drugs = set(human_group['drug'].astype(str))
        species_drugs = set(preclinical_df_filtered[preclinical_df_filtered['species_group'] == species]['drug'].astype(str))
        human_drugs_tested_in_species = species_drugs.intersection(human_drugs)
        if len(human_drugs_tested_in_species) == 0:
            return results
        try:
            preclinical_group = preclinical_df_grouped.get_group((soc, species, ae))
        except KeyError:
            return results
        preclinical_drugs = set(preclinical_group['drug'].astype(str))
        tn_drugs, fp_drugs, fn_drugs, tp_drugs = compute_stats_with_drugs(human_drugs_tested_in_species, preclinical_drugs, species_drugs)
        contingency_table = [[len(tp_drugs), len(fp_drugs)], [len(fn_drugs), len(tn_drugs)]]
        _, p_value = fisher_exact(contingency_table)
        results.append({
            'SOC': soc,
            'AE': ae,
            'Species': species,
            'TP': len(tp_drugs),
            'TP_Drugs': ', '.join(tp_drugs),
            'FN': len(fn_drugs),
            'FN_Drugs': ', '.join(fn_drugs),
            'FP': len(fp_drugs),
            'FP_Drugs': ', '.join(fp_drugs),
            'TN': len(tn_drugs),
            'Fisher_p_value': p_value
        })
        return results

    def process_soc_ae_combined(soc, ae, human_df_grouped, preclinical_df_filtered):
        results = []
        try:
            human_group = human_df_grouped.get_group((soc, ae))
        except KeyError:
            return results
        human_drugs = set(human_group['drug'].astype(str))
        combined_species_drugs = set(preclinical_df_filtered['drug'].astype(str))
        human_drugs_tested_in_any_species = combined_species_drugs.intersection(human_drugs)
        if len(human_drugs_tested_in_any_species) == 0:
            return results
        preclinical_group = preclinical_df_filtered[(preclinical_df_filtered['SOC'] == soc) & (preclinical_df_filtered['adverse_event'] == ae)]
        preclinical_drugs = set(preclinical_group['drug'].astype(str))
        tn_drugs, fp_drugs, fn_drugs, tp_drugs = compute_stats_with_drugs(human_drugs_tested_in_any_species, preclinical_drugs, combined_species_drugs)
        contingency_table = [[len(tp_drugs), len(fp_drugs)], [len(fn_drugs), len(tn_drugs)]]
        _, p_value = fisher_exact(contingency_table)
        results.append({
            'SOC': soc,
            'AE': ae,
            'Species': 'Combined',
            'TP': len(tp_drugs),
            'TP_Drugs': ', '.join(tp_drugs),
            'FN': len(fn_drugs),
            'FN_Drugs': ', '.join(fn_drugs),
            'FP': len(fp_drugs),
            'FP_Drugs': ', '.join(fp_drugs),
            'TN': len(tn_drugs),
            'Fisher_p_value': p_value
        })
        return results

    # run combinations
    results = []
    with concurrent.futures.ProcessPoolExecutor() as executor:
        futures = []
        for soc in tqdm(human_df_filtered['SOC'].unique(), desc="Processing SOC Terms"):
            ae_list = human_df_filtered[human_df_filtered['SOC'] == soc]['adverse_event'].unique()
            for ae in ae_list:
                for species in preclinical_df_filtered['species_group'].unique():
                    futures.append(executor.submit(process_soc_ae_species, soc, ae, species, human_df_grouped, preclinical_df_grouped))
                futures.append(executor.submit(process_soc_ae_combined, soc, ae, human_df_grouped, preclinical_df_filtered))
        for future in tqdm(concurrent.futures.as_completed(futures), desc="Collecting results"):
            results.extend(future.result())

    results_df = pd.DataFrame(results)
    results_df['PPV'] = results_df['TP'] / (results_df['TP'] + results_df['FP'])
    results_df['NPV'] = results_df['TN'] / (results_df['TN'] + results_df['FN'])
    results_df['Positive_Likelihood_Ratio'] = (results_df['TP'] / (results_df['TP'] + results_df['FN'])) / \
                                               (results_df['FP'] / (results_df['FP'] + results_df['TN']))
    results_df['Negative_Likelihood_Ratio'] = (results_df['FN'] / (results_df['TP'] + results_df['FN'])) / \
                                               (results_df['TN'] / (results_df['FP'] + results_df['TN']))
    results_df["1/Negative_Likelihood_Ratio"] = results_df["Negative_Likelihood_Ratio"].apply(lambda x: 1/x if x != 0 else np.inf)

    def p_value_correction(group, method='bonferroni'):
        group['Adjusted_p_value'] = multipletests(group['Fisher_p_value'], method=method, alpha=0.05)[1]
        return group
    results_df = results_df.groupby(['SOC', 'Species']).apply(p_value_correction)
    results_df.reset_index(drop=True, inplace=True)

    # annotate 
    drug_targets = pd.read_csv("./drugbank_offx_targets.csv") # retrieve primary secondary targets from drugbank and off-x with licnese
    df_target_4map_dict = dict(zip(drug_targets.drug_name, drug_targets.targets))
    def map_drug_targets(drug_list, drug_target_dict):
        if pd.isna(drug_list):
            return []
        drug_list = [drug.strip() for drug in drug_list.split(',')] if isinstance(drug_list, str) else []
        target_list = []
        for drug in drug_list:
            targets = drug_target_dict.get(drug, [])
            if isinstance(targets, str) and targets != 'nan':
                try:
                    targets = eval(targets)
                except:
                    targets = []
            target_list.extend(targets)
        return list(set(target_list))
    tqdm.pandas()
    results_df['TP_Targets'] = results_df['TP_Drugs'].progress_apply(lambda x: map_drug_targets(x, df_target_4map_dict))
    results_df['FN_Targets'] = results_df['FN_Drugs'].progress_apply(lambda x: map_drug_targets(x, df_target_4map_dict))
    results_df['FP_Targets'] = results_df['FP_Drugs'].progress_apply(lambda x: map_drug_targets(x, df_target_4map_dict))

    results_df.to_csv(f"concordance_results_{drug_type.replace(' ', '_')}.csv", index=False)
    print(f"Saved results for {drug_type} to concordance_results_{drug_type.replace(' ', '_')}.csv")

# PK matched concordance
def array_remove_py(list1, list2):
    return list(set(list1) - set(list2))

df_pk = pd.read_csv("PK_safety_concordance.csv") # matched PK for studies downloaded from PP with license

pk_pairs = df_pk.merge(
    df_pk,
    on=["Drug", "Parameter"],
    suffixes=('_hu', '_an')
)
pk_pairs = pk_pairs[
    (pk_pairs["Human_Animal_hu"] == "Human") &
    (pk_pairs["Human_Animal_an"] == "Animal") &
    (abs(pk_pairs["Log10_normalized_value_avg_hu"] - pk_pairs["Log10_normalized_value_avg_an"]) <= 1)
]

tp = pk_pairs[
    (pk_pairs["SOC_terms_hu"] == pk_pairs["SOC_terms_an"]) &
    (pk_pairs["Adverse Effect / Toxicity_hu"] == pk_pairs["Adverse Effect / Toxicity_an"])
]

tp_grouped = tp.groupby([
    "Human_Animal_hu", "Human_Animal_an", "SOC_terms_hu", "Adverse Effect / Toxicity_hu", "Adverse Effect / Toxicity_an", "Parameter"
]).agg({
    "Drug": lambda x: list(set(x)),
    "Log10_normalized_value_avg_hu": "first",
    "Log10_normalized_value_avg_an": "first"
}).reset_index().rename(columns={
    "Adverse Effect / Toxicity_hu": "hu_ae",
    "Adverse Effect / Toxicity_an": "pc_ae",
    "Drug": "tp_drugs",
    "Log10_normalized_value_avg_hu": "hu_pk",
    "Log10_normalized_value_avg_an": "pc_pk",
    "SOC_terms_hu": "SOC_terms"
})

tp_grouped["tp"] = tp_grouped["tp_drugs"].apply(len)

animal_aes = df_pk[df_pk["Human_Animal"] == "Animal"].groupby("Adverse Effect / Toxicity")["Drug"].unique().reset_index()
animal_aes = animal_aes.rename(columns={"Adverse Effect / Toxicity": "pc_ae", "Drug": "all_animal_drugs"})

human_aes = df_pk[df_pk["Human_Animal"] == "Human"].groupby("Adverse Effect / Toxicity")["Drug"].unique().reset_index()
human_aes = human_aes.rename(columns={"Adverse Effect / Toxicity": "hu_ae", "Drug": "all_human_drugs"})

fp = animal_aes.merge(tp_grouped, on="pc_ae", how="left")
fp["fp_drugs"] = fp.apply(lambda row: array_remove_py(row["all_animal_drugs"], row["tp_drugs"] if isinstance(row["tp_drugs"], list) else []), axis=1)
fp["fp"] = fp["fp_drugs"].apply(len)

fn = human_aes.merge(tp_grouped, on="hu_ae", how="left")
fn["fn_drugs"] = fn.apply(lambda row: array_remove_py(row["all_human_drugs"], row["tp_drugs"] if isinstance(row["tp_drugs"], list) else []), axis=1)
fn["fn"] = fn["fn_drugs"].apply(len)

tn = animal_aes.merge(fp, on="pc_ae", suffixes=('', '_fp'))
tn["tn_drugs"] = tn.apply(lambda row: array_remove_py(row["all_animal_drugs"], row["fp_drugs"] if isinstance(row["fp_drugs"], list) else []), axis=1)
tn["tn"] = tn["tn_drugs"].apply(len)

results = tp_grouped.merge(fp, left_on="pc_ae", right_on="pc_ae", how="outer")\
                    .merge(fn, left_on="hu_ae", right_on="hu_ae", how="outer")\
                    .merge(tn, left_on="pc_ae", right_on="pc_ae", how="outer")

final_results = results[[
    "hu_ae", "pc_ae", "tp", "tp_drugs", "fp", "fp_drugs", "fn", "fn_drugs", "tn", "tn_drugs"
]]

final_results.to_csv("pk_concordance.csv", index=False)

